<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">

<?php

$_REQUEST['login'];

$options = array(
    'http' => array(
        'method' => "GET",
        'header' => "Accept-language: en\r\n" .
            "Cookie: foo=bar\r\n" .  // check function.stream-context-create on php.net
            "User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:20.0) Gecko/20100101 Firefox/20.0"
    )
);

$context = stream_context_create($options);
//$codiFont = file_get_contents("http://" . $url, false, $context);

$login = $_REQUEST['login'];
$url = "https://api.github.com/users/";
$respuesta = $url . $login;
$json = file_get_contents($respuesta, false, $context);
$datos = json_decode($json, true);
//print_r($datos);

//$items = $datos['items'];


?>

<div class="container" style="margin-top:50px">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-2">
                    Login: <?php echo $datos['login']; ?> <br>
                    Tipo: <?php echo $datos['type']; ?> <br>
                    Nombre: <?php echo $datos['name']; ?> <br>
                    Compañia: <?php echo $datos['company']; ?> <br>
                </div>
                <div class="col-md-10"><?php echo '<img src='.$datos["avatar_url"].' width="100px">'; ?></div>
            </div>
        </div>
    </div>
</div>