<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/25375dedf3.js" crossorigin="anonymous"></script>
    <title>Document</title>
</head>

<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <div class="container">
            <div class="row" style="margin-top:100px">
                <div class="col-lg-3"></div>
                <div class="col-lg-3"><input type="text" name="nombre" class="form-control" placeholder="Nombre a consultar"></div>
                <div class="col-lg-3"><button class="btn btn-success btn-sm form-control" type="submit" name="enviar">Consultar</button></div>
                <div class="col-lg-3"></div>
            </div>
        </div>
    </form>

    <?php



    if (isset($_REQUEST['enviar'])) {

        $options = array(
            'http' => array(
                'method' => "GET",
                'header' => "Accept-language: en\r\n" .
                    "Cookie: foo=bar\r\n" .  // check function.stream-context-create on php.net
                    "User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:20.0) Gecko/20100101 Firefox/20.0"
            )
        );

        $context = stream_context_create($options);
        //$codiFont = file_get_contents("http://" . $url, false, $context);

        $nombre = $_REQUEST['nombre'];
        $url = "https://api.github.com/search/users?q=";
        $respuesta = $url . $nombre;
        $json = file_get_contents($respuesta, false, $context);
        $datos = json_decode($json, true);
        //print_r($datos);

        $items = $datos['items'];
    }
    ?>
    <br>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Login</th>
                    <th>Avatar</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item) {
                ?>
                    <tr>
                        <td><?php echo $item['login']; ?></td>
                        <td><?php echo $item['id']; ?></td>
                        <td><?php echo '<img src='.$item["avatar_url"].' width="30px">'; ?></td>
                        <td><a href="detalle.php?login=<?php echo $item['login']; ?>"><i class="fa-regular fa-pen-to-square"></i></a></td>
                    </tr>
                <?php } ?>

            </tbody>
        </table>
    </div>

</body>

</html>