<?php
function create(){

$stmt = $this->conn->prepare("
INSERT INTO ".$this->itemsTable."('id', 'usuario', 'fecha_creacion', 'fecha_actualizacion', 'estado')
VALUES(?,?,?,?,?)");

$this->usuario = htmlspecialchars(strip_tags($this->usuario));
$this->fecha_creacion = htmlspecialchars(strip_tags($this->fecha_creacion));
$this->fecha_actualizacion = htmlspecialchars(strip_tags($this->fecha_actualizacion));
$this->estado = htmlspecialchars(strip_tags($this->estado));



$stmt->bind_param("ssiis", $this->usuario, $this->fecha_creacion, $this->fecha_actualizacion, $this->estado);

if($stmt->execute()){
return true;
}

return false; 
}
?>